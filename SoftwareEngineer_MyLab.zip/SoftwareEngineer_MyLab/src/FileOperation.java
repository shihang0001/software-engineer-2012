
public interface FileOperation {
	public void writeStringToFile();
	public void writeIntToFile();
	public void readStringFromFile();
	public void readIntFromFile();
}
